public class Contacto {
   private String nombre;
   private String telefono;
   private String email;
   private String cum;
   private String tipo;
   
   
   
   //Zona Sets
   public void setNombre(String nombre) {
      this.nombre = nombre;
   }
   
   public void setTelefono(String telefono) {
      this.telefono = telefono;  
   }
   
   public void setEmail(String email) {
      this.email = email;
   }
   
   public void setCum(String cum) {
      this.cum = cum; 
   }
   
   public void setTipo(String tipo) {
        this.tipo = tipo;
   }
   
   //Zona gets
   public String getNombre() {
      return nombre;
   }
   
   public String getTelefono() {
      return telefono;
   }
   
   public String getEmail() {
      return email;
   }
   
   public String getCum() {
      return cum;
   }
   
   public String getTipo() {
     return tipo;
   }
}

















