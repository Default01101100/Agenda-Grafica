import javax.swing.*;
import java.awt.*;

public class JFrameRitmo extends JFrame {
   Ritmo ritmo = new Ritmo();
  
   public JFrameRitmo() {
      initComponents();
   }
   
   private void initComponents() {
      setSize(500,250);
      setTitle("Ritmo");

      setResizable(true);
      setVisible(true);
      
      setContentPane(ritmo); 
   }
}