public class PrincipalAgenda {
   public static void main (String args[]) {
      
      //CreacionVentanaPrincipal inicio = new CreacionVentanaPrincipal();
      JFrameIngreso2022 elist = new JFrameIngreso2022();

   }
}